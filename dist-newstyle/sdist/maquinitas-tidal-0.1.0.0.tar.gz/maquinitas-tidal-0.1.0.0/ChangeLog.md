# Revision history for maquinitas

## 0.1.0.0 -- 2019-12-17

* First version. Testing build of package, add first four instruments.
